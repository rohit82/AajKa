package com.capgemini.view;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;
import com.capgemini.service.IProductService;
import com.capgemini.service.ProductServiceImpl;

public class Menu {

	private IProductService productService;

	public Menu() {
		productService = new ProductServiceImpl();
	}

	public void menu() {
		Scanner console = new Scanner(System.in);

		System.out.println("1) Add Product");
		System.out.println("2) Get Product");
		System.out.println("3) Update Product");
		System.out.println("4) Remove Product");
		System.out.println("5) View all Product");
		System.out.println("6) Get Product by Name");
		System.out.println("9) Exit Application");

		int choice = console.nextInt();

		switch (choice) {
		case 1:
			System.out.println(" Enter Product Name :");
			String name = console.next();

			System.out.println(" Enter Product Quantity :");
			int qty = console.nextInt();

			System.out.println(" Enter Product Price");
			float price = console.nextFloat();

			Product p1 = new Product(name, qty, price);

			try {
				int productId = productService.addProduct(p1);

				System.out.println("Product Inserted Succesfully id ="
						+ productId);

			} catch (ProductException e) {
				System.out.println("could not add product.Reason :"
						+ e.getMessage());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}

			break;

		case 2:

			System.out.println("Enter the productID to retrieve product info ");
			System.out.println("product Id");
			int productId = console.nextInt();

			try {
				Product p2 = productService.getProduct(productId);
				System.out.println("ID : " + p2.getId());
				System.out.println("Name :" + p2.getName());
				System.out.println("Quantity : " + p2.getQuantity());
				System.out.println("Price : " + p2.getPrice());

			} catch (ProductException e) {
				System.out.println("could not add product.Reason :"
						+ e.getMessage());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			break;

		case 3:
			System.out.println(" Enter the product Id to update : ");

			int uid = console.nextInt();
			Product p3 = null;

			try {
				p3 = productService.getProduct(uid);
				System.out.println("Old product name : " + p3.getName());
				System.out.println(" Update ? y/n");
				char reply = console.next().toLowerCase().charAt(0);

				if (reply == 'y') {
					System.out.println("Enter new name ");
					String newName = console.next();
					p3.setName(newName);

				}

				System.out
						.println("Old product Quantity : " + p3.getQuantity());
				System.out.println(" Update ? y/n");
				reply = console.next().toLowerCase().charAt(0);

				if (reply == 'y') {
					System.out.println("Enter new quantity ");
					int newQty = console.nextInt();
					p3.setQuantity(newQty);

				}

				System.out.println("Old product price : " + p3.getPrice());
				System.out.println(" Update ? y/n");
				reply = console.next().toLowerCase().charAt(0);

				if (reply == 'y') {
					System.out.println("Enter new price ");
					float newPrice = console.nextFloat();

					p3.setPrice(newPrice);

				}

			} catch (ProductException e) {
				System.out.println("Product not found please try again "
						+ e.getMessage());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}

			try {
				if (p3 != null)
					productService.updateProduct(p3);

			} catch (ProductException e) {
				System.out.println("could not update product. Reason  "
						+ e.getMessage());

			} catch (Exception e) {
				System.out.println(e.getMessage());
			}

			break;

		case 4:
			System.out.println("Enter Product Id to remove product ");

			System.out.println("Product id : ");
			int rid = console.nextInt();
			try {
				productService.removeProduct(rid);

			}

			catch (ProductException e) {
				System.out.println("could not remove product. Reason "
						+ e.getMessage());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}

			break;
		case 5:
			try {
				List<Product> products = productService.getAllProducts();

				Iterator<Product> it = products.iterator();

				System.out.printf("%5s %6s %8s %s \n", "ID", "Name",
						"Quantity", "Price");
				while (it.hasNext())

				{
					Product product = it.next();
					System.out.printf("%5s %6s %8s %s \n", product.getId(),
							product.getName(), product.getQuantity(),
							product.getPrice());

				}
			} catch (ProductException e) {
				System.out.println(" Could not display : Reason"
						+ e.getMessage());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			break;
		case 6:

			System.out.println("Enter product name ");
			System.out.println("Product Name");

			String proname = console.next();

			try {

				List<Product> p2 = productService.getProuctbyName(proname);
				Iterator<Product> it = p2.iterator();
				System.out.printf("%6s %7s %18s %s", "ID", "Name", "Quantity",
						"Price\n");

				while (it.hasNext()) {

					Product product = it.next();
					System.out.printf("%4d %7s %5d %11f \n", product.getId(),
							product.getName(), product.getQuantity(),
							product.getPrice());

				}

			}

			catch (Exception e)

			{

				System.out.println("Could not find product with this name"
						+ e.getMessage());

			}

			break;
		case 9:

			System.exit(0);
			break;

		default:
			System.out.println("Invalid Choice ");
			break;
		}

	}

	public static void main(String[] args) {

		Menu application = new Menu();

		while (true) {
			try {
				application.menu();
			} catch (Exception e) {
				System.out.println("Something went wrong : message : "
						+ e.getMessage());
			}

		}

	}

}
