package com.capgemini.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.capgemini.entities.Product;

public class ProductMapper implements RowMapper
{

	@Override
	public Object mapRow(ResultSet res, int rowNumber) throws SQLException {
          
		Product product = new Product();
		
		product.setId(res.getInt("pid"));
		product.setName(res.getString("pname"));
		product.setQuantity(res.getInt("pquantity"));
		product.setPrice(res.getFloat("price"));
		
		return product;
	}

}
