package com.capgemini.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;
import com.capgemini.util.DBUtil;


@Component("productDAO")
public class ProductDaoImpl implements IProductDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public ProductDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public ProductDaoImpl(JdbcTemplate jdbcTemplate) {
		super();
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public int addProduct(Product product) throws ProductException {

		int productId;
		try {
			productId = jdbcTemplate.queryForObject(
					"select hibernate_sequence.nextval from dual",
					Integer.class);

			String query = "insert into ProductDetails values(?,?,?,?)";

			Object[] params = new Object[] { productId, product.getName(),
					product.getQuantity(), product.getPrice() };
			jdbcTemplate.update(query, params);
		} catch (DataAccessException e) {
			throw new ProductException(e.getMessage());

		}

		return productId;
	}

	@Override
	public void updateProduct(Product product) throws ProductException {

		try
		{

			String query = "update ProductDetails set pname=? ,  pquantity=? , price = ?";

			Object[] params = new Object[] { product.getName(),
					product.getQuantity(), product.getPrice(), product.getId() };
			jdbcTemplate.update(query, params);
		} 
		catch (DataAccessException e) 
		{
			throw new ProductException(e.getMessage());

		}
	}

	@Override
	public Product getProduct(int id) throws ProductException {
		
		Product product = null;
		try {
			String query = "Select * from ProductDetails where pid=?";
			
			 product = (Product) jdbcTemplate.queryForObject(query, new ProductMapper(), id);
		} catch (Exception e) {
			
			throw new ProductException("No product found with id " + id );
		}
		
		
		return product;
	}

	@Override
	public void removeProduct(int id) throws ProductException {
 
	}

	@Override
	public List<Product> getAllProducts() throws ProductException {
		
		List<Product> pList;
		 try 
		 {
			String sql = "SELECT * FROM ProductDetails";
			   pList =getJdbcTemplate().query(sql,new ProductMapper());
		} 
		 catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
		   return pList;
		

	}

	@Override
	public List<Product> getProuctbyName(String name) throws ProductException {
		List<Product> pname;

		try {
			String sql = "SELECT pname FROM ProductDetails WHERE pid=?";
			pname = getJdbcTemplate().query(sql,new ProductMapper());
		}
		catch (Exception e) {
			throw new ProductException(e.getMessage());

		}
		return pname;
		
	}

}
