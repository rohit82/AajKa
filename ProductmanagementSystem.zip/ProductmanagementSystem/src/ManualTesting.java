import com.capgemini.entities.Product;
import com.capgemini.service.ProductServiceImpl;

public class ManualTesting {

	public static void main(String[] args) {

		ProductServiceImpl productService = new ProductServiceImpl();

		Product p1 = new Product("HTCSmartwatch", 10, 2300);

		// testing add product method

		int id = productService.addProduct(p1);

		System.out.println(" product inserted with id" + id);

		// testing get product method
		Product p2 = productService.getProduct(id);

		System.out.println(p2);

		// testing update product method

		Product p3 = new Product(id, "HTCSmartWatch", 5, 20000);

		productService.updateProduct(p3);

		System.out.println(productService.getProduct(id));

		// testing remove product method

		productService.removeProduct(id);
		System.out.println(productService.getProduct(id));

	}

}
