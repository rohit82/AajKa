create table ProductDetails(
pid NUMBER(6) PRIMARY KEY,
pname VARCHAR2(30),
pquantity NUMBER,
price NUMBER(8,2)  
);

drop table ProductDetails;

delete from ProductDetails

select * from ProductDetails;

select hibernate_sequence.nextval from dual


update ProductDetails set pname="HTCSmartPhone" where pid=2;