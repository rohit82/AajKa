package com.capgemini.util;

public class SpringContainerUtil
{

}
