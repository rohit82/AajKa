package com.capgemini.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;

@Component("productDAO")
public class ProductDAOImpl implements IProductDAO 
{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public ProductDAOImpl() {
		// TODO Auto-generated constructor stub
	}
	
	

	public ProductDAOImpl(JdbcTemplate jdbcTemplate) {
		super();
		this.jdbcTemplate = jdbcTemplate;
	}



	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}



	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}



	@Override
	public int addProduct(Product product) throws ProductException 
	{
		
		int productId = 0;
		try
		{
			productId = jdbcTemplate.queryForObject("select hibernate_sequence.nextval from dual", Integer.class);
			
			String query = "insert into ProductDetails values(?,?,?,?)";
			
			Object[] params = new Object[]{productId , product.getName() , product.getQuantity() , product.getPrice()};
			
			jdbcTemplate.update(query , params);
		}
		catch (DataAccessException e) 
		{
			throw new ProductException(e.getMessage());
		}
		
		return productId;
	}

	@Override
	public void update(Product product) throws ProductException 
	{
		try
		{
			
			String query = "update ProductDetails set pname=?, pquantity=?, price=? where pid=?";
			
			Object[] params = new Object[]{product.getName() , product.getQuantity() , product.getPrice(), product.getId()};
			
			jdbcTemplate.update(query , params);
		}
		catch (DataAccessException e) 
		{
			throw new ProductException(e.getMessage());
		}
		

	}

	@Override
	public Product getProduct(int id) throws ProductException 
	{
		Product product;
		try 
		{
			String query = "select * from ProductDetails where pid=?";
			
			product = (Product) jdbcTemplate.queryForObject(query, new ProductMapper());
		}
		catch (DataAccessException e) 
		{
			throw new ProductException(e.getMessage());
		}
		
		if(product == null)
			throw new ProductException("No product found with id "+ id);
		
		return product;
	}

	@Override
	public void removeProduct(int id) throws ProductException 
	{
		Product product = new Product();
		try
		{
			
			String query = "delete from ProductDetails where pid=?";
			
			Object[] params = new Object[]{product.getId()};
			
			jdbcTemplate.update(query , params);
		}
		catch (DataAccessException e) 
		{
			throw new ProductException(e.getMessage());
		}

	}

	@Override
	public List<Product> getAllProducts() throws ProductException 
	{
		List<Product> pList;
		try 
		{
			String query = "select * from ProductDetails";
			
			pList =  jdbcTemplate.query(query, new ProductMapper());
		}
		catch (DataAccessException e) 
		{
			throw new ProductException(e.getMessage());
		}
		
		if(pList == null)
			throw new ProductException("No product found  ");
		
		return pList;
	}

	@Override
	public List<Product> getProductByName(String name) throws ProductException 
	{
		List<Product> pList;
		try 
		{
			String query = "select * from ProductDetails where pname=?";
			
			pList =  jdbcTemplate.query(query, new ProductMapper());
		}
		catch (DataAccessException e) 
		{
			throw new ProductException(e.getMessage());
		}
		
		if(pList == null)
			throw new ProductException("No product found with name "+ name);
		
		return pList;
	}

	@Override
	public List<Product> getProductByRange(float low, float high)
			throws ProductException {
		List<Product> pList;
		try 
		{
			String query = "select * from ProductDetails where price<? and price>?";
			
			Object[] params = new Object[]{high , low};
			
			pList =  jdbcTemplate.query(query, new ProductMapper(), params);
	
		}
		catch (DataAccessException e) 
		{
			throw new ProductException(e.getMessage());
		}
		
		if(pList == null)
			throw new ProductException("No product found in this range");
		
		return pList;
	}

}
