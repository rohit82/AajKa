package com.capgemini.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.dao.ProductDAOImpl;
import com.capgemini.entities.Product;
import com.capgemini.service.IProductService;
import com.capgemini.service.ProductServiceImpl;

public class MainApp 
{
	public static void main(String[] args) 
	{
		
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		IProductService productservice = context.getBean("productService" , ProductServiceImpl.class);
		
		Product product = new Product(41,"Samsung" , 1, 12000);
		
		productservice.addProduct(product);
		productservice.getProduct(2);
		System.out.println(productservice.getProduct(2));
		
		
		
		
		
		/*ProductDAOImpl productservice = new ProductDAOImpl();
		
		Product product = new Product("MotoG2" , 1, 23000);
		
		//testing add product
		
		int id= productservice.addProduct(product);
		System.out.println("Product inserted with id "+ id);
		
		//testing get product method
		
		Product p2 = productservice.getProduct(id);
		System.out.println(p2);
		
		//testing update product method
		
		Product p3 = new Product(id, "HTCSmartCover" , 5, 20000);
		productservice.update(p3);
		
		//testing remove product method
		
		productservice.removeProduct(id);		
		System.out.println( productservice.getProduct(id));*/
	}

}
