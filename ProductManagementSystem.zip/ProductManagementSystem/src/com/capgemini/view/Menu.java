package com.capgemini.view;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;
import com.capgemini.service.IProductService;
import com.capgemini.service.ProductServiceImpl;

public class Menu
{

	IProductService productService;
	
	public Menu() 
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		 productService = context.getBean("productService" , ProductServiceImpl.class);
	}
	
	public void menu()
	{
		Scanner console = new Scanner(System.in);
		
		System.out.println("1) Add Product");
		System.out.println("2) Get Product By Id");
		System.out.println("3) Get Product By Name");
		System.out.println("4) Get Product By Range");
		System.out.println("5) Update Product");
		System.out.println("6) Remove Product");
		System.out.println("7) View All Product");		
		System.out.println("9) Exit Application");
		
		int choice= console.nextInt();
		
		switch (choice)
		{
			case 1:
			
				System.out.println("Enter Product Name : ");
				String name = console.next();
				
				System.out.println("Enter Product Quantity : ");
				int qty = console.nextInt();
				
				System.out.println("Enter Product Price: ");
				float price = console.nextFloat();
				
				Product p1 = new Product(name, qty, price);
				
				try
				{
					int productId = productService.addProduct(p1);
					
					System.out.println("Product inserted successfully with id = "+productId);
				}
				catch (ProductException e) 
				{
					System.out.println("Could not add product. Reason : "+e.getMessage());
				}
				catch (Exception e) 
				{
					System.out.println(e.getMessage());
				}
				
				break;
				
			case 2:
				
				System.out.println("Enter the product id to retrieve Product Info");
				System.out.print("Product Id: ");
				int productId = console.nextInt();

				try
				{
					Product p2 = productService.getProduct(productId);
					
					System.out.println("Id: "+ p2.getId());
					System.out.println("Name: "+ p2.getName());
					System.out.println("Quantity: "+ p2.getQuantity());
					System.out.println("Price: "+ p2.getPrice());
					
				}
				catch (ProductException e) 
				{
					System.out.println("Could not find the product. Reason : "+e.getMessage());
				}
				catch (Exception e) 
				{
					System.out.println(e.getMessage());
				}
				
				break;
				
			case 3:
				try 
				{
					System.out.println("Enter product name to be search");
					System.out.print("Product name : ");
					String sname= console.next();
					List<Product> products = productService.getProductByName(sname);
					
					Iterator<Product> it = products.iterator();
					
					System.out.println("List of searched Products");
					System.out.println(" ");
					
					System.out.printf("%4s %6s %15s %16s \n", "Id" , "Name" , "Quantity", "Price");
					while(it.hasNext())
					{
						Product product = it.next();
						System.out.printf("%4d %6s %10d %13f \n" ,
								product.getId() , product.getName() ,
								product.getQuantity() , product.getPrice());
					}
				}
				catch (ProductException e) 
				{
					System.out.println("Product not found. Reason : "+e.getMessage());
				}
				catch (Exception e) 
				{
					System.out.println(e.getMessage());
				}	
				
				break;
				
			case 4:
				try 
				{
					System.out.println("Enter product Range to be search");
					System.out.print("Minimum Range : ");
					float lrange= console.nextFloat();
					
					System.out.print("Maximum Range : ");
					float hrange= console.nextFloat();
					
					List<Product> products = productService.getProductByRange(lrange, hrange);
					
					Iterator<Product> it = products.iterator();
					
					System.out.println("List of searched Products");
					System.out.println(" ");
					
					System.out.printf("%4s %6s %15s %16s \n", "Id" , "Name" , "Quantity", "Price");
					while(it.hasNext())
					{
						Product product = it.next();
						System.out.printf("%4d %6s %10d %13f \n" ,
								product.getId() , product.getName() ,
								product.getQuantity() , product.getPrice());
					}
				}
				catch (ProductException e) 
				{
					System.out.println("Product not found. Reason : "+e.getMessage());
				}
				catch (Exception e) 
				{
					System.out.println(e.getMessage());
				}	
				
				break;
				
			case 5:
				
				System.out.println("Enter Product id to update: ");
				int uId = console.nextInt();
				Product p3 = null;
				
				try
				{
					 p3 = productService.getProduct(uId);
					
					System.out.println("Old Product Name: "+ p3.getName());
					System.out.println("Do you want to update? y/n");
					char reply = console.next().toLowerCase().charAt(0);
					
					if(reply == 'y')
					{
						System.out.println("Enter new name");
						String newName = console.next();
						p3.setName(newName);
					}
					
					System.out.println("Old Product Quantity: "+ p3.getQuantity());
					System.out.println("Do you want to update? y/n");
					reply = console.next().toLowerCase().charAt(0);
					
					if(reply == 'y')
					{
						System.out.println("Enter new Quantity");
						int newQty = console.nextInt();
						p3.setQuantity(newQty);
						
					}
					
					
					System.out.println("Old Product Price: "+ p3.getPrice());
					System.out.println("Do you want to update? y/n");
				    reply = console.next().toLowerCase().charAt(0);
					
					if(reply == 'y')
					{
						System.out.println("Enter new Price");
						float newPrice = console.nextFloat();
						p3.setPrice(newPrice);
					}
					
					
				}
				catch (ProductException e) 
				{
					System.out.println("Product not found. Reason : "+e.getMessage());
				}
				catch (Exception e) 
				{
					System.out.println(e.getMessage());
				}
				

				try
				{
					 if(p3 != null)
							 productService.update(p3);
				
				}
				catch (ProductException e) 
				{
					System.out.println("Could not update Product. Reason : "+e.getMessage());
				}
				catch (Exception e) 
				{
					System.out.println(e.getMessage());
				}
				
				break;
				
			case 6:
				
				System.out.println("Enter the product id to remove Product");
				System.out.print("Product Id: ");
				int rId = console.nextInt();

				try
				{
					productService.removeProduct(rId);
					
				}
				catch (ProductException e) 
				{
					System.out.println("Could not remove the product. Reason : "+e.getMessage());
				}
				catch (Exception e) 
				{
					System.out.println(e.getMessage());
				}
				break;
				
			case 7:
				try 
				{
					List<Product> products = productService.getAllProducts();
					
					Iterator<Product> it = products.iterator();
					
					System.out.println("List of Products");
					System.out.println(" ");
					
					System.out.printf("%4s %6s %15s %18s \n", "Id" , "Name" , "Quantity", "Price");
					while(it.hasNext())
					{
						Product product = it.next();
						System.out.printf("%4d %6s %10d %15f \n" ,
								product.getId() , product.getName() ,
								product.getQuantity() , product.getPrice());
					}
				}
				catch (ProductException e) 
				{
					System.out.println("Could not display all the products. Reason : "+e.getMessage());
				}
				catch (Exception e) 
				{
					System.out.println(e.getMessage());
				}	
				
				break;
				
				
			
			
			case 9:
				System.exit(0);
				break;

		default:
			System.out.println("Invalid choice");
			break;
		}
	}
	
	public static void main(String[] args) 
	{
		Menu application = new Menu();
		
		while(true)
		{
			try
			{
				application.menu();
			}
			catch(Exception e)
			{
				System.out.println("Something went wrong: "+e.getMessage());
			}
			
		}

	}

}
