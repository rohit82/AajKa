package com.capgemini.beans;

import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

public class ProductDetails {
	
	@Min(value=1000,message="pro")
	private int productId;
	
	@NotEmpty
	@Pattern(regexp="[A-Z][a-z]{3,30}")
	private String productname;
	
	@Min(value=1)
	private int productprice;
	
	public ProductDetails() {
		// TODO Auto-generated constructor stub
	}

	public ProductDetails(int productId, String productname, int productprice) {
		super();
		this.productId = productId;
		this.productname = productname;
		this.productprice = productprice;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public int getProductprice() {
		return productprice;
	}

	public void setProductprice(int productprice) {
		this.productprice = productprice;
	}

	@Override
	public String toString() {
		return "ProductDetails [productId=" + productId + ", productname="
				+ productname + ", productprice=" + productprice + "]";
	}
	
	
	
}
