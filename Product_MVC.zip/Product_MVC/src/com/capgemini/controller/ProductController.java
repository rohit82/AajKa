package com.capgemini.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.beans.ProductDetails;


@Controller
public class ProductController 
{
	@RequestMapping("add")
	public String addProduct()
	{
		return "AddProductPage";
	}

	@RequestMapping("showProductDetails")
	public String showProduct(@ModelAttribute("product") 
	@Valid ProductDetails productDetails,BindingResult result,Model model)
	{
		if(result.hasErrors()==true)
		{
			return "ErrorPage";
		}
		else
		{
	
		model.addAttribute("product",productDetails);
		return "SuccessPage";
	}}
}
