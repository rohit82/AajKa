package com.capgemini.gym.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.gym.dao.IBookingDAO;
import com.capgemini.gym.entities.Customer;
import com.capgemini.gym.exception.BookingException;

@Service("bookingService")
@Transactional
public class BookingServiceImpl implements IBookingService
{
	@Autowired
	IBookingDAO bookingDAO ;
	
	public BookingServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	
	
	@Override
	public String toString() {
		return "BookingServiceImpl [bookingDAO=" + bookingDAO + "]";
	}


	public IBookingDAO getBookingDAO() {
		return bookingDAO;
	}


	public void setBookingDAO(IBookingDAO bookingDAO) {
		this.bookingDAO = bookingDAO;
	}


	public BookingServiceImpl(IBookingDAO bookingDAO) {
		super();
		this.bookingDAO = bookingDAO;
	}


	@Override
	public int addCustomer(Customer customer) throws BookingException {
		// TODO Auto-generated method stub
		return bookingDAO.addCustomer(customer);
	}


	@Override
	public Customer getCustomer(int id) throws BookingException {
		// TODO Auto-generated method stub
		return bookingDAO.getCustomer(id);
	}


	@Override
	public void updateCustomer(Customer customer) throws BookingException {
		bookingDAO.updateCustomer(customer);
	}


	@Override
	public List<Customer> getAllCustomers() throws BookingException {
		// TODO Auto-generated method stub
		return bookingDAO.getAllCustomers();
	}


	@Override
	public void deleteCustomer(int id) throws BookingException {
		bookingDAO.deleteCustomer(id);
	}
	
	
}
