package com.capgemini.gym.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.gym.entities.Customer;
import com.capgemini.gym.exception.BookingException;

@Repository("bookingDAO")
public class BookingDAOImpl implements IBookingDAO
{
	@PersistenceContext
	private EntityManager entityManager ;
	
	public BookingDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	public BookingDAOImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public int addCustomer(Customer customer) throws BookingException 
	{
		int id = -1;
		try
		{
			System.out.println("in dao try");
			entityManager.persist(customer);
			id = customer.getId() ;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public Customer getCustomer(int id) throws BookingException {
		Customer customer  = null ;
		try
		{
			customer = entityManager.find(Customer.class, id) ;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new BookingException(e.getMessage());
		}
		if(customer == null )
		{
			throw new BookingException("Customer Not Found With Id " + id);
		}
		
		return customer;
		
		
	}

	@Override
	public void updateCustomer(Customer customer) throws BookingException {
		
		try
		{
			entityManager.merge(customer) ;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new BookingException(e.getMessage());
		}
		
	}

	@Override
	public List<Customer> getAllCustomers() throws BookingException {
		List<Customer> cList = new ArrayList<Customer>();
		try
		{
			//TypedQuery<Customer> query = entityManager.createNamedQuery("GetAllCustomers",Customer.class) ;
			//cList = query.getResultList() ;
			cList = entityManager.createQuery("select c from Customer c").getResultList();
		
		}
		catch(Exception e)
		{
			throw new BookingException(e.getMessage());
		}
		
		return cList ;
	}

	@Override
	public void deleteCustomer(int id) throws BookingException 
	{
		Customer customer= null ;
		try
		{
			 customer = entityManager.find(Customer.class, id) ;
			 entityManager.remove(customer);
		}
		catch(Exception e)
		{
			throw new BookingException(e.getMessage());
		}
	}
	
	
	
}
