package com.cg.ems.service;

import java.sql.SQLException;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.dao.IEmployeeDAO;
import com.cg.ems.entities.Employee;
import com.cg.ems.entities.User;
import com.cg.ems.exception.EmployeeException;

@Transactional
@Service("employeeService")
public class EmployeeServiceImpl implements IEmployeeService
{
	@Autowired
	private IEmployeeDAO employeeDAO;

	public EmployeeServiceImpl() {
		super();
	}

	public EmployeeServiceImpl(IEmployeeDAO employeeDAO) 
	{
		super();
		this.employeeDAO = employeeDAO;
	}

	public IEmployeeDAO getEmployeeDAO() 
	{
		return employeeDAO;
	}

	public void setEmployeeDAO(IEmployeeDAO employeeDAO) 
	{
		this.employeeDAO = employeeDAO;
	}

	@Override
	public void addEmployeeDetails(Employee emp) throws EmployeeException 
	{
		employeeDAO.addEmployeeDetails(emp);
		
	}

	@Override
	public int addLoginDetails(User user) throws EmployeeException 
	{
		return employeeDAO.addLoginDetails(user);
	}

	@Override
	public List<Employee> showAllEmployees() throws EmployeeException,SQLException 
	{
		return employeeDAO.showAllEmployees();
	}

	@Override
	public int isValid(String userName, String userPassword)throws EmployeeException 
	{
		return employeeDAO.isValid(userName, userPassword);
	}

	@Override
	public Employee searchEmployeeById(String EmpId) throws EmployeeException 
	{
		return employeeDAO.searchEmployeeById(EmpId);
	}

	@Override
	public List<Employee> searchEmployeeByFirstName(String firstName)throws EmployeeException 
	{
		return employeeDAO.searchEmployeeByFirstName(firstName);
	}

	@Override
	public List<Employee> searchEmployeeByLastName(String lastName)throws EmployeeException 
	{
		return employeeDAO.searchEmployeeByLastName(lastName);
	}

	@Override
	public List<Employee> searchEmployeeByDepartment(String empDept1,
			String empDept2, String empDept3, String empDept4, String empDept5,
			String empDept6) throws EmployeeException 
	{
		return employeeDAO.searchEmployeeByDepartment(empDept1, empDept2, empDept3, empDept4, empDept5, empDept6);
	}

	@Override
	public List<Employee> searchEmployeeByGrade(String grade1, String grade2,
			String grade3, String grade4, String grade5, String grade6,
			String grade7) throws EmployeeException 
   {
		
		return employeeDAO.searchEmployeeByGrade(grade1, grade2, grade3, grade4, grade5, grade6, grade7);
	}

	@Override
	public List<Employee> searchEmployeeByMaritalStatus(String status1,
			String status2, String status3, String status4, String status5)throws EmployeeException 
	{
		return employeeDAO.searchEmployeeByMaritalStatus(status1, status2, status3, status4, status5);
	}

	@Override
	public void updateEmployeeDetails(Employee emp) throws EmployeeException 
	{
		employeeDAO.updateEmployeeDetails(emp);
		
		
	}
	
	
   
	
}
