package com.cg.ems.dao;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;




import com.cg.ems.entities.Employee;
import com.cg.ems.entities.Grade;
import com.cg.ems.entities.User;
import com.cg.ems.exception.EmployeeException;

@Repository("employeeDAO")
public class EmployeeDAOImpl implements IEmployeeDAO
{
	@PersistenceContext
	private EntityManager entityManager;

	public EmployeeDAOImpl() 
	{
		super();
	}

	@Override
	public void addEmployeeDetails(Employee emp) throws EmployeeException 
	{
	
		try 
		{
			entityManager.persist(emp);
	     
		} 
		catch (Exception e) 
		{
			
			throw new EmployeeException(e.getMessage());
		}
		
	}

	@Override
	public int addLoginDetails(User user) throws EmployeeException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Employee> showAllEmployees() throws EmployeeException,
			SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int isValid(String userName, String userPassword)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Employee searchEmployeeById(String EmpId) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> searchEmployeeByFirstName(String firstName)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> searchEmployeeByLastName(String lastName)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> searchEmployeeByDepartment(String empDept1,
			String empDept2, String empDept3, String empDept4, String empDept5,
			String empDept6) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> searchEmployeeByGrade(String grade1, String grade2,
			String grade3, String grade4, String grade5, String grade6,
			String grade7) throws EmployeeException 
	{
		
		List<Employee> employees=null;
		
		try 
		{
			TypedQuery<Employee> tQuery=entityManager.createQuery("SELECT E.EMP_ID,E.EMP_FIRST_NAME,E.EMP_LAST_NAME,E.EMP_DATE_OF_BIRTH,"
				+ "E.EMP_DATE_OF_JOINING,E.EMP_DEPT_ID,E.EMP_BASIC,E.EMP_GRADE,E.EMP_DESIGNATION,E.EMP_GENDER,E.EMP_MARITAL_STATUS,"
				+ "E.EMP_HOME_ADDRESS,E.EMP_CONTACT_NUM,G.DESCRIPTION,G.MIN_SALARY,G.MAX_SALARY FROM EMPLOYEE E, GRADE_MASTER G "
				+ "WHERE E.EMP_GRADE=G.GRADE_CODE AND (G.GRADE_CODE=? OR G.GRADE_CODE=? OR G.GRADE_CODE=? OR  G.GRADE_CODE=? OR G.GRADE_CODE=? OR G.GRADE_CODE=? OR G.GRADE_CODE=?",Employee.class,Grade.class);
	     
			employees=tQuery.getResultList();
		} 
		catch (Exception e) 
		{
			
			throw new EmployeeException(e.getMessage());
		}
		
		return employees;
	}

	@Override
	public List<Employee> searchEmployeeByMaritalStatus(String status1,
			String status2, String status3, String status4, String status5)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateEmployeeDetails(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		
	}

	
	
	

}
