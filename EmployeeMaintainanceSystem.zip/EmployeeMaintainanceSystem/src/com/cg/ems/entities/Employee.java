package com.cg.ems.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Employee")
public class Employee 
{
	@Id
	@NotEmpty(message="Employee ID Cannot be empty")
	@Column(name="Emp_ID")
	private String empId;
	
	@NotEmpty(message="Employee first name Cannot be empty")
	@Column(name="Emp_First_Name")
	private String empFname;
	
	@NotEmpty(message="Employee last name Cannot be empty")
	@Column(name="Emp_Last_Name")
	private String empLname;
	
	
	@Column(name="Emp_Date_of_Birth")
	private Date empDateOfBirth;
	
	@Column(name="Emp_Date_of_Joining")
	private Date empDateOfJoining;
	
	@Min(value=20,message="Department id Cannot be empty")
	@Column(name="Emp_Dept_ID")
	private int empDeptId;
	
	@NotEmpty(message="Employee grade Cannot be empty")
	@Column(name="Emp_Grade")
	private String empGrade;
	
	@Min(value=12000,message="Employee Salary cannot be lass than 12000")
	@Max(value=200000,message="Employee Salary cannot be greater than 200000")
	@Column(name="Emp_Basic")
	private int empBasic;
	
	@NotEmpty(message="Employee designation Cannot be empty")
	@Column(name="Emp_Designation")
	private String empDesignation;
	
	@NotEmpty(message="Employee gender Cannot be empty")
	@Column(name="Emp_Gender")
	private String empGender;
	
	@NotEmpty(message="Employee marital status Cannot be empty")
	@Column(name="Emp_Marital_Status")
	private String empMaritalStatus;
	
	@NotEmpty(message="Employee address Cannot be empty")
	@Column(name="Emp_Home_Address")
	private String empHomeAddress;
	
	@NotEmpty(message="Employee contact Cannot be empty")
	@Column(name="Emp_Contact_num")
	private String empContactNo;
	
	private Department dept;
	
	private Grade grade;

	public Employee() {
		super();
	}

	public Employee(String empFname, String empLname, Date empDateOfBirth,
			Date empDateOfJoining, int empDeptId, String empGrade,
			int empBasic, String empDesignation, String empGender,
			String empMaritalStatus, String empHomeAddress,
			String empContactNo, Department dept, Grade grade) {
		super();
		this.empFname = empFname;
		this.empLname = empLname;
		this.empDateOfBirth = empDateOfBirth;
		this.empDateOfJoining = empDateOfJoining;
		this.empDeptId = empDeptId;
		this.empGrade = empGrade;
		this.empBasic = empBasic;
		this.empDesignation = empDesignation;
		this.empGender = empGender;
		this.empMaritalStatus = empMaritalStatus;
		this.empHomeAddress = empHomeAddress;
		this.empContactNo = empContactNo;
		this.dept = dept;
		this.grade = grade;
	}

	public Employee(String empId, String empFname, String empLname,
			Date empDateOfBirth, Date empDateOfJoining, int empDeptId,
			String empGrade, int empBasic, String empDesignation,
			String empGender, String empMaritalStatus, String empHomeAddress,
			String empContactNo, Department dept, Grade grade) {
		super();
		this.empId = empId;
		this.empFname = empFname;
		this.empLname = empLname;
		this.empDateOfBirth = empDateOfBirth;
		this.empDateOfJoining = empDateOfJoining;
		this.empDeptId = empDeptId;
		this.empGrade = empGrade;
		this.empBasic = empBasic;
		this.empDesignation = empDesignation;
		this.empGender = empGender;
		this.empMaritalStatus = empMaritalStatus;
		this.empHomeAddress = empHomeAddress;
		this.empContactNo = empContactNo;
		this.dept = dept;
		this.grade = grade;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpFname() {
		return empFname;
	}

	public void setEmpFname(String empFname) {
		this.empFname = empFname;
	}

	public String getEmpLname() {
		return empLname;
	}

	public void setEmpLname(String empLname) {
		this.empLname = empLname;
	}

	public Date getEmpDateOfBirth() {
		return empDateOfBirth;
	}

	public void setEmpDateOfBirth(Date empDateOfBirth) {
		this.empDateOfBirth = empDateOfBirth;
	}

	public Date getEmpDateOfJoining() {
		return empDateOfJoining;
	}

	public void setEmpDateOfJoining(Date empDateOfJoining) {
		this.empDateOfJoining = empDateOfJoining;
	}

	public int getEmpDeptId() {
		return empDeptId;
	}

	public void setEmpDeptId(int empDeptId) {
		this.empDeptId = empDeptId;
	}

	public String getEmpGrade() {
		return empGrade;
	}

	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}

	public int getEmpBasic() {
		return empBasic;
	}

	public void setEmpBasic(int empBasic) {
		this.empBasic = empBasic;
	}

	public String getEmpDesignation() {
		return empDesignation;
	}

	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}

	public String getEmpGender() {
		return empGender;
	}

	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}

	public String getEmpMaritalStatus() {
		return empMaritalStatus;
	}

	public void setEmpMaritalStatus(String empMaritalStatus) {
		this.empMaritalStatus = empMaritalStatus;
	}

	public String getEmpHomeAddress() {
		return empHomeAddress;
	}

	public void setEmpHomeAddress(String empHomeAddress) {
		this.empHomeAddress = empHomeAddress;
	}

	public String getEmpContactNo() {
		return empContactNo;
	}

	public void setEmpContactNo(String empContactNo) {
		this.empContactNo = empContactNo;
	}

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	public Grade getGrade() {
		return grade;
	}

	public void setGrade(Grade grade) {
		this.grade = grade;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empFname=" + empFname
				+ ", empLname=" + empLname + ", empDateOfBirth="
				+ empDateOfBirth + ", empDateOfJoining=" + empDateOfJoining
				+ ", empDeptId=" + empDeptId + ", empGrade=" + empGrade
				+ ", empBasic=" + empBasic + ", empDesignation="
				+ empDesignation + ", empGender=" + empGender
				+ ", empMaritalStatus=" + empMaritalStatus
				+ ", empHomeAddress=" + empHomeAddress + ", empContactNo="
				+ empContactNo + ", dept=" + dept + ", grade=" + grade + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((empId == null) ? 0 : empId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (empId == null) {
			if (other.empId != null)
				return false;
		} else if (!empId.equals(other.empId))
			return false;
		return true;
	}
	
	
	
}
	
	
	
	