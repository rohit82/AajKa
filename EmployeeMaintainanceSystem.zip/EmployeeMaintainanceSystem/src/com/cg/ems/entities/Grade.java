package com.cg.ems.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Grade_Master")
public class Grade 
{
    @Id
    @Column(name="Grade_Code")
	private String gradeCode;
    
    @NotEmpty(message="Grade description Cannot be empty")
    @Column(name="Description")
	private String gradeDescription;
    
    @Min(value=12000,message="Minimum salary could not be less than 12000")
    @Column(name="Min_Salary")
	private int gradeMinSalary;
    
    @Max(value=200000,message="Maximum salary could not be greater than 200000")
    @Column(name="Max_Salary")
	private int gradeMaxsalary;

	public Grade() {
		super();
	}

	public Grade(String gradeDescription, int gradeMinSalary, int gradeMaxsalary) {
		super();
		this.gradeDescription = gradeDescription;
		this.gradeMinSalary = gradeMinSalary;
		this.gradeMaxsalary = gradeMaxsalary;
	}

	public Grade(String gradeCode, String gradeDescription, int gradeMinSalary,
			int gradeMaxsalary) {
		super();
		this.gradeCode = gradeCode;
		this.gradeDescription = gradeDescription;
		this.gradeMinSalary = gradeMinSalary;
		this.gradeMaxsalary = gradeMaxsalary;
	}

	public String getGradeCode() {
		return gradeCode;
	}

	public void setGradeCode(String gradeCode) {
		this.gradeCode = gradeCode;
	}

	public String getGradeDescription() {
		return gradeDescription;
	}

	public void setGradeDescription(String gradeDescription) {
		this.gradeDescription = gradeDescription;
	}

	public int getGradeMinSalary() {
		return gradeMinSalary;
	}

	public void setGradeMinSalary(int gradeMinSalary) {
		this.gradeMinSalary = gradeMinSalary;
	}

	public int getGradeMaxsalary() {
		return gradeMaxsalary;
	}

	public void setGradeMaxsalary(int gradeMaxsalary) {
		this.gradeMaxsalary = gradeMaxsalary;
	}

	@Override
	public String toString() {
		return "Grade [gradeCode=" + gradeCode + ", gradeDescription="
				+ gradeDescription + ", gradeMinSalary=" + gradeMinSalary
				+ ", gradeMaxsalary=" + gradeMaxsalary + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((gradeCode == null) ? 0 : gradeCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Grade other = (Grade) obj;
		if (gradeCode == null) {
			if (other.gradeCode != null)
				return false;
		} else if (!gradeCode.equals(other.gradeCode))
			return false;
		return true;
	}
	
	
	
	
	
}
