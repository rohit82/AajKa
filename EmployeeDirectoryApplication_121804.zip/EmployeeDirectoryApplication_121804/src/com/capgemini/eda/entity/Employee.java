package com.capgemini.eda.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Max;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@NamedQueries(@NamedQuery(name="GetAllEmployees",query="select e from Employee e"))
public class Employee {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="mygen")
	@SequenceGenerator(name="mygen",sequenceName="hibernate_sequence",initialValue=1000)
	private int employee_code;
	
	@NotEmpty(message="Employee name cannot be empty")
	//@Max(value=40,message="Employee Name cannot be more than 40 characters")
	private String employee_name;
	
	@NotEmpty(message="Gender should be selected ")
	private String employee_gender;
	
	@NotEmpty(message="Designation name should be selected")
	private String designation_name;
	
	@NotEmpty(message="Email cannot be empty")
	@Email(message="Email is invalid")
	private String employee_email;
	
	@Pattern(regexp="[7-9]{1}[0-9]{9}")
	private String employee_phone;
	
	
	public Employee() {
		super();
	}
	public Employee(int employee_code, String employee_name,
			String employee_gender, String designation_name,
			String employee_email, String employee_phone) {
		super();
		this.employee_code = employee_code;
		this.employee_name = employee_name;
		this.employee_gender = employee_gender;
		this.designation_name = designation_name;
		this.employee_email = employee_email;
		this.employee_phone = employee_phone;
	}
	public Employee(String employee_name, String employee_gender,
			String designation_name, String employee_email, String employee_phone) {
		super();
		this.employee_name = employee_name;
		this.employee_gender = employee_gender;
		this.designation_name = designation_name;
		this.employee_email = employee_email;
		this.employee_phone = employee_phone;
	}
	public int getEmployee_code() {
		return employee_code;
	}
	public void setEmployee_code(int employee_code) {
		this.employee_code = employee_code;
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	public String getEmployee_gender() {
		return employee_gender;
	}
	public void setEmployee_gender(String employee_gender) {
		this.employee_gender = employee_gender;
	}
	public String getDesignation_name() {
		return designation_name;
	}
	public void setDesignation_name(String designation_name) {
		this.designation_name = designation_name;
	}
	public String getEmployee_email() {
		return employee_email;
	}
	public void setEmployee_email(String employee_email) {
		this.employee_email = employee_email;
	}
	public String getEmployee_phone() {
		return employee_phone;
	}
	public void setEmployee_phone(String employee_phone) {
		this.employee_phone = employee_phone;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + employee_code;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (employee_code != other.employee_code)
			return false;
		return true;
	}
	
	
}
