package com.capgemini.eda.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.eda.dao.IEmployeeDAO;
import com.capgemini.eda.entity.Employee;
import com.capgemini.eda.exception.EmployeeException;

@Service("employeeService")
@Transactional
public class EmployeeServiceImpl implements IEmployeeService 
{
	@Autowired
	private IEmployeeDAO employeeDAO;

	public EmployeeServiceImpl() {
		super();
	}

	public EmployeeServiceImpl(IEmployeeDAO employeeDAO) {
		super();
		this.employeeDAO = employeeDAO;
	}

	public IEmployeeDAO getEmployeeDAO() {
		return employeeDAO;
	}

	public void setEmployeeDAO(IEmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}
	
	
	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		
		return employeeDAO.addEmployee(employee);
	}

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.getAllEmployees();
	}
	
	
}
