package com.capgemini.eda.service;

import java.util.List;

import com.capgemini.eda.entity.Employee;
import com.capgemini.eda.exception.EmployeeException;

public interface IEmployeeService 
{
	public int  addEmployee(Employee employee) throws EmployeeException;
	public List<Employee> getAllEmployees() throws EmployeeException;
	
}
