package com.capgemini.eda.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.eda.entity.Employee;
import com.capgemini.eda.exception.EmployeeException;
import com.capgemini.eda.service.IEmployeeService;


@Controller
public class EmployeeController
{
	@Autowired
	private IEmployeeService employeeService;

	public EmployeeController() {
		super();
	}

	public EmployeeController(IEmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}

	public IEmployeeService getEmployeeService() {
		return employeeService;
	}

	public void setEmployeeService(IEmployeeService employeeService) {
		this.employeeService = employeeService;
	}
	
	@RequestMapping("home")
	public String getHomePage()
	{
		return "HomePage";
	}
	
	@RequestMapping("addemployee")
	public String getAddEmployeePage(Model model)
	{
		List<String> gender = new ArrayList<>();
		gender.add("Male");
		gender.add("Female");
		
		List<String> designation = new ArrayList<>();
		designation.add("Software Engineer");
		designation.add("Senior Software Engineer");
		designation.add("Team Lead");
		designation.add("Manager");
		
		model.addAttribute("gender", gender);
		model.addAttribute("designation", designation);
		model.addAttribute("employee", new Employee());
		
		return "AddEmployeePage";
	}
	
	@RequestMapping("ProcessAddEmployeeForm")
	public  String addEmployeeDetails(@ModelAttribute("employee") @Valid Employee employee , BindingResult result , Model model ) throws EmployeeException
	{
		if(result.hasErrors() == true)
		{
			List<String> gender = new ArrayList<>();
			gender.add("Male");
			gender.add("Female");
			
			List<String> designation = new ArrayList<>();
			designation.add("Software Engineer");
			designation.add("Senior Software Engineer");
			designation.add("Team Lead");
			designation.add("Manager");
			
			model.addAttribute("gender", gender);
			model.addAttribute("designation", designation);
			model.addAttribute("employee", employee);
			return "AddEmployeePage";
		}
		else
		{
			int employeeId= -1;
			try 
			{
				employeeId= employeeService.addEmployee(employee);
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
				model.addAttribute("errMsg", "something went wrong");
				return "ErrorPage";
			}
			model.addAttribute("successMsg", "Employee added Successfully and the employee code is:" +employeeId);
			return "SuccessPage";
		}
	}
	
	@RequestMapping("viewallemployee")
	public String getViewAllEmployeesPage(Model model)
	{
		List<Employee> employees = null;
		try {
			employees = employeeService.getAllEmployees();
			model.addAttribute("employees", employees);
		} 
		catch (Exception e) 
		{
			model.addAttribute("errMsg", "could not display employees.Reason:" +e.getMessage());
			return "ErrorPage";
		}
		return "ViewAllEmployeesPage";
}
}