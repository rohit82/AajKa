package com.capgemini.eda.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.eda.entity.Employee;
import com.capgemini.eda.exception.EmployeeException;



@Repository("employeeDAO")
public class EmployeeDAOImpl implements IEmployeeDAO
{
	@PersistenceContext
	private EntityManager entityManager;

	public EmployeeDAOImpl() {
		super();
	}

	public EmployeeDAOImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	
	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		int employeeId=0;
		try
		{
			entityManager.persist(employee);
			
			employeeId=employee.getEmployee_code();
	
		}
		catch(Exception e)
		{
			
			
			throw new EmployeeException(e.getMessage());
		}
		return employeeId;
	}

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		List<Employee> employees =null;
		try
		{

			TypedQuery<Employee> tQuery=entityManager.createNamedQuery("GetAllProducts",Employee.class);
			
			employees = tQuery.getResultList();
			
			
		}
		catch(Exception e)
		{
			throw new EmployeeException(e.getMessage());
		}
		
		if (employees==null ||employees.isEmpty())
			throw new EmployeeException("No Employee to display ");
		return employees;
	}
	}
	
	
	
	
	

