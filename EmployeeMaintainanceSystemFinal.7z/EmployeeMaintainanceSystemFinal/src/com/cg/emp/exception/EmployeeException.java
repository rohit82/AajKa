package com.cg.emp.exception;

public class EmployeeException extends Exception {

	public EmployeeException() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EmployeeException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EmployeeException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public EmployeeException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
