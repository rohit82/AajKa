package com.cg.emp.dto;

import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name="Grade_Master")
public class Grade {

	
	private String gradeCode;
	private String gradeDescription;
	private int gradeMinSalary;
	private int gradeMaxsalary;
	
	
	public Grade() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Grade(String gradeCode, String gradeDescription,
			int gradeMinSalary, int gradeMaxsalary) {
		super();
		this.gradeCode = gradeCode;
		this.gradeDescription = gradeDescription;
		this.gradeMinSalary = gradeMinSalary;
		this.gradeMaxsalary = gradeMaxsalary;
	}


	public String getGradeCode() {
		return gradeCode;
	}


	public void setGradeCode(String gradeCode) {
		this.gradeCode = gradeCode;
	}


	public String getGradeDescription() {
		return gradeDescription;
	}


	public void setGradeDescription(String gradeDescription) {
		this.gradeDescription = gradeDescription;
	}


	public int getGradeMinSalary() {
		return gradeMinSalary;
	}


	public void setGradeMinSalary(int gradeMinSalary) {
		this.gradeMinSalary = gradeMinSalary;
	}


	public int getGradeMaxsalary() {
		return gradeMaxsalary;
	}


	public void setGradeMaxsalary(int gradeMaxsalary) {
		this.gradeMaxsalary = gradeMaxsalary;
	}


	@Override
	public String toString() {
		return "Grade [gradeCode=" + gradeCode + ", gradeDescription="
				+ gradeDescription + ", gradeMinSalary=" + gradeMinSalary
				+ ", gradeMaxsalary=" + gradeMaxsalary + "]";
	}
	
	
	
	
}
