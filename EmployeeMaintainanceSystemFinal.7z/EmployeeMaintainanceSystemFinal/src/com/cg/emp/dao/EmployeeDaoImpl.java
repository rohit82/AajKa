package com.cg.emp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;




import com.cg.emp.dto.Department;
import com.cg.emp.dto.Employee;
import com.cg.emp.dto.Grade;
import com.cg.emp.dto.User;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao
{

	@Override
	public int addEmployeeDetails(Employee emp) throws EmployeeException {
		
		return 0;
	}

	@Override
	public int addLoginDetails(User user) throws EmployeeException {
		
		return 0;
	}

	@Override
	public List<Employee> showAll() throws EmployeeException, SQLException {
	
		return null;
	}

	@Override
	public int isValid(String userName, String userPassword)
			throws EmployeeException {
		
		return 0;
	}

	@Override
	public Employee searchEmployeeOnId(String EmpId) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> searchEmployeeOnFirstName(String firstName)
			throws EmployeeException 
			{
	
		return null;
	}

	@Override
	public List<Employee> searchEmployeeOnLastName(String lastName)
			throws EmployeeException {
		
		return null;
	}

	@Override
	public List<Employee> searchEmployeeOnDepartment(String empDept1,
			String empDept2, String empDept3, String empDept4, String empDept5,
			String empDept6) throws EmployeeException {

		return null;
	}

	@Override
	public List<Employee> searchEmployeeOnGrade(String grade1, String grade2,
			String grade3, String grade4, String grade5, String grade6,
			String grade7) throws EmployeeException {
	
		return null;
	}

	@Override
	public List<Employee> searchEmployeeOnMaritalStatus(String status1,
			String status2, String status3, String status4, String status5)
			throws EmployeeException {
		
		return null;
	}

	@Override
	public void updateEmployee(Employee emp) throws EmployeeException {
	
		
	}
	

	
}
